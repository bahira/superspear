// SPEAR — Symbolic Pareto Evolutionary Algorithm for Research
// Engine v2: seeded RNG, algebraic simplification, affine wrapping, constant
// refinement (coordinate descent), full NSGA-II (non-dominated sort +
// crowding distance), Pareto archive and code generation.

export type NodeOp =
  | "var" | "const"
  | "add" | "sub" | "mul" | "pdiv"
  | "relu" | "abs" | "neg" | "sq" | "sqrt" | "cube"
  | "max" | "min";

export interface SpearNode {
  op: NodeOp;
  value: number;
  name: string;
  children: SpearNode[];
  size: number;
  depth: number;
}

const BINARY = new Set<NodeOp>(["add", "sub", "mul", "pdiv", "max", "min"]);
const UNARY = new Set<NodeOp>(["relu", "abs", "neg", "sq", "sqrt", "cube"]);

export const ALL_OPS: NodeOp[] = [
  "add", "sub", "mul", "pdiv", "relu", "abs", "neg", "sq", "sqrt", "cube", "max", "min",
];

/** Ops that a GPU/TPU executes as plain algebra (no transcendental unit). */
export const ALGEBRAIC_OPS = new Set<NodeOp>([
  "add", "sub", "mul", "pdiv", "relu", "abs", "neg", "sq", "cube", "max", "min",
]);

export function arity(op: NodeOp): number {
  if (op === "var" || op === "const") return 0;
  if (BINARY.has(op)) return 2;
  if (UNARY.has(op)) return 1;
  return 0;
}

// ---------------------------------------------------------------- seeded RNG
let rngState = 0x2f6e2b1;

export function setSeed(seed: number): void {
  rngState = (seed >>> 0) || 1;
}

export function rand(): number {
  rngState = (rngState + 0x6d2b79f5) >>> 0;
  let t = rngState;
  t = Math.imul(t ^ (t >>> 15), t | 1);
  t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
}

function randRange(min: number, max: number): number {
  return min + rand() * (max - min);
}

export function randInt(maxExclusive: number): number {
  return Math.floor(rand() * maxExclusive);
}

function pick<T>(arr: readonly T[]): T {
  return arr[randInt(arr.length)];
}

/** Relative cost of each operator in ALU/SFU units on a modern GPU. */
export const OP_COST: Record<NodeOp, number> = {
  var: 0, const: 0,
  add: 1, sub: 1, mul: 1,
  pdiv: 4, relu: 1, abs: 1, neg: 1, sq: 1, cube: 2, sqrt: 2, max: 1, min: 1,
};

export function estimateCost(node: SpearNode): number {
  let total = 0;
  const walk = (nd: SpearNode) => {
    total += OP_COST[nd.op] ?? 1;
    nd.children.forEach(walk);
  };
  walk(node);
  return total;
}

/** Backward-elimination pruning: drop subtrees that do not hurt the score. */
export function prune(
  node: SpearNode,
  score: (n: SpearNode) => number,
  tolerance = 1.002,
): { node: SpearNode; score: number; removed: number } {
  let current = cloneNode(node);
  let currentScore = score(current);
  let removed = 0;
  for (let pass = 0; pass < 3; pass++) {
    const positions: SpearNode[] = [];
    const collect = (nd: SpearNode) => {
      if (nd.children.length > 0) positions.push(nd);
      nd.children.forEach(collect);
    };
    collect(current);
    let improvedThisPass = false;
    for (const target of positions) {
      const candidates: SpearNode[] = [];
      if (target.children[0]) candidates.push(target.children[0]);
      if (target.children[1]) candidates.push(target.children[1]);
      for (const rep of candidates) {
        const trial = replaceForPrune(current, target, cloneNode(rep));
        const s = score(trial);
        if (Number.isFinite(s) && s <= currentScore * tolerance) {
          current = trial;
          currentScore = s;
          removed++;
          improvedThisPass = true;
          break;
        }
      }
    }
    if (!improvedThisPass) break;
  }
  const cleaned = simplify(current);
  const cleanedScore = score(cleaned);
  if (Number.isFinite(cleanedScore) && cleanedScore <= currentScore * tolerance) {
    return { node: cleaned, score: cleanedScore, removed };
  }
  return { node: current, score: currentScore, removed };
}

function replaceForPrune(root: SpearNode, target: SpearNode, rep: SpearNode): SpearNode {
  if (root === target) return rep;
  if (root.children.length === 0) return root;
  return makeNode(root.op, {
    value: root.value, name: root.name,
    children: root.children.map((c) => replaceForPrune(c, target, rep)),
  });
}

// ---------------------------------------------------------------- node utils
export function makeNode(
  op: NodeOp,
  opts: { value?: number; name?: string; children?: SpearNode[] } = {},
): SpearNode {
  const children = opts.children ?? [];
  const size = 1 + children.reduce((s, c) => s + c.size, 0);
  const depth = 1 + children.reduce((m, c) => Math.max(m, c.depth), 0);
  return { op, value: opts.value ?? 0, name: opts.name ?? "", children, size, depth };
}

export function cloneNode(n: SpearNode): SpearNode {
  return makeNode(n.op, {
    value: n.value,
    name: n.name,
    children: n.children.map(cloneNode),
  });
}

export function roundConst(v: number): number {
  return Math.abs(v) < 1e-6 ? 0 : Number(v.toFixed(6));
}

// ---------------------------------------------------------------- evaluation
export function evaluateNode(
  node: SpearNode,
  vars: Record<string, Float64Array>,
  n: number,
): Float64Array {
  switch (node.op) {
    case "var": {
      const v = vars[node.name];
      if (!v) throw new Error(`Unknown variable "${node.name}"`);
      return v;
    }
    case "const": {
      const out = new Float64Array(n);
      out.fill(node.value);
      return out;
    }
    default: break;
  }
  if (BINARY.has(node.op)) {
    const a = evaluateNode(node.children[0], vars, n);
    const b = evaluateNode(node.children[1], vars, n);
    const out = new Float64Array(n);
    for (let i = 0; i < n; i++) {
      const av = a[i];
      const bv = b[i];
      let r = 0;
      switch (node.op) {
        case "add": r = av + bv; break;
        case "sub": r = av - bv; break;
        case "mul": r = av * bv; break;
        case "pdiv": {
          let d = bv;
          if (d > -1e-4 && d < 1e-4) d = d >= 0 ? 1e-4 : -1e-4;
          r = av / d;
          if (r > 1e4) r = 1e4;
          else if (r < -1e4) r = -1e4;
          break;
        }
        case "max": r = av > bv ? av : bv; break;
        case "min": r = av < bv ? av : bv; break;
        default: break;
      }
      out[i] = r;
    }
    return out;
  }
  const a = evaluateNode(node.children[0], vars, n);
  const out = new Float64Array(n);
  for (let i = 0; i < n; i++) {
    const av = a[i];
    let r = 0;
    switch (node.op) {
      case "relu": r = av > 0 ? av : 0; break;
      case "abs": r = av < 0 ? -av : av; break;
      case "neg": r = -av; break;
      case "sq": r = av * av; break;
      case "cube": r = av * av * av; break;
      case "sqrt": r = Math.sqrt(av < 0 ? -av : av); break;
      default: break;
    }
    out[i] = r;
  }
  return out;
}

export function evaluateScalar(node: SpearNode, scope: Record<string, number>): number {
  switch (node.op) {
    case "var": return scope[node.name] ?? 0;
    case "const": return node.value;
    default: break;
  }
  const a = node.children.map((c) => evaluateScalar(c, scope));
  switch (node.op) {
    case "add": return a[0] + a[1];
    case "sub": return a[0] - a[1];
    case "mul": return a[0] * a[1];
    case "pdiv": {
      let d = a[1];
      if (d > -1e-4 && d < 1e-4) d = d >= 0 ? 1e-4 : -1e-4;
      const r = a[0] / d;
      return Math.max(-1e4, Math.min(1e4, r));
    }
    case "max": return Math.max(a[0], a[1]);
    case "min": return Math.min(a[0], a[1]);
    case "relu": return a[0] > 0 ? a[0] : 0;
    case "abs": return Math.abs(a[0]);
    case "neg": return -a[0];
    case "sq": return a[0] * a[0];
    case "cube": return a[0] * a[0] * a[0];
    case "sqrt": return Math.sqrt(Math.abs(a[0]));
    default: return 0;
  }
}

// ---------------------------------------------------------------- printing
function fmt(v: number): string {
  const r = roundConst(v);
  return Number.isInteger(r) ? r.toString() : r.toString();
}

export function nodeToString(node: SpearNode): string {
  switch (node.op) {
    case "var": return node.name;
    case "const": return fmt(node.value);
    case "relu": return `relu(${nodeToString(node.children[0])})`;
    case "abs": return `|${nodeToString(node.children[0])}|`;
    case "neg": return `(-${nodeToString(node.children[0])})`;
    case "sq": return `(${nodeToString(node.children[0])})²`;
    case "cube": return `(${nodeToString(node.children[0])})³`;
    case "sqrt": return `sqrt(|${nodeToString(node.children[0])}|)`;
    case "max": return `max(${nodeToString(node.children[0])}, ${nodeToString(node.children[1])})`;
    case "min": return `min(${nodeToString(node.children[0])}, ${nodeToString(node.children[1])})`;
    case "pdiv": return `(${nodeToString(node.children[0])} / ${nodeToString(node.children[1])})`;
    case "add": return `(${nodeToString(node.children[0])} + ${nodeToString(node.children[1])})`;
    case "sub": return `(${nodeToString(node.children[0])} - ${nodeToString(node.children[1])})`;
    case "mul": return `(${nodeToString(node.children[0])} * ${nodeToString(node.children[1])})`;
    default: return "?";
  }
}

const PY: Record<NodeOp, string> = {
  var: "", const: "",
  add: "({a} + {b})", sub: "({a} - {b})", mul: "({a} * {b})",
  pdiv: "({a} / (abs({b}) < 1e-4 ? 1e-4 : {b}))",
  relu: "torch.relu({a})", abs: "torch.abs({a})", neg: "(-{a})",
  sq: "({a} * {a})", cube: "({a} * {a} * {a})", sqrt: "torch.sqrt(torch.abs({a}))",
  max: "torch.maximum({a}, {b})", min: "torch.minimum({a}, {b})",
};

export function toPython(node: SpearNode, fnName = "spear_fn"): string {
  const walk = (nd: SpearNode): string => {
    if (nd.op === "var") return nd.name;
    if (nd.op === "const") return fmt(nd.value);
    if (nd.op === "cube") return `(${walk(nd.children[0])} ** 3)`;
    if (UNARY.has(nd.op)) return PY[nd.op].replace("{a}", walk(nd.children[0]));
    return PY[nd.op].replace("{a}", walk(nd.children[0])).replace("{b}", walk(nd.children[1]));
  };
  const args = [...new Set(collectVarNames(node))].join(", ");
  return `import torch\n\ndef ${fnName}(${args}):\n    # Evolved by SPEAR — zero transcendental ops (exp/erf/tanh free)\n    return ${walk(node)}`;
}

export function toC(node: SpearNode, fnName = "spear_fn", varDecl = "const float x"): string {
  const walk = (nd: SpearNode): string => {
    if (nd.op === "var") return nd.name;
    if (nd.op === "const") return `${fmt(nd.value)}f`;
    switch (nd.op) {
      case "relu": return `fmaxf(0.0f, ${walk(nd.children[0])})`;
      case "abs": return `fabsf(${walk(nd.children[0])})`;
      case "neg": return `(-${walk(nd.children[0])})`;
      case "sq": return `powf(${walk(nd.children[0])}, 2.0f)`;
      case "cube": return `powf(${walk(nd.children[0])}, 3.0f)`;
      case "sqrt": return `sqrtf(fabsf(${walk(nd.children[0])}))`;
      case "max": return `fmaxf(${walk(nd.children[0])}, ${walk(nd.children[1])})`;
      case "min": return `fminf(${walk(nd.children[0])}, ${walk(nd.children[1])})`;
      case "pdiv": return `(${walk(nd.children[0])} / ${walk(nd.children[1])})`;
      default: break;
    }
    return `(${walk(nd.children[0])} ${nd.op === "add" ? "+" : nd.op === "sub" ? "-" : "*"} ${walk(nd.children[1])})`;
  };
  return `// Evolved by SPEAR — algebraic only, FP16 safe\n__device__ inline float ${fnName}(${varDecl}) {\n    return ${walk(node)};\n}`;
}

export function collectVarNames(node: SpearNode): string[] {
  const out: string[] = [];
  const walk = (nd: SpearNode) => {
    if (nd.op === "var") out.push(nd.name);
    nd.children.forEach(walk);
  };
  walk(node);
  return out;
}

export function countOps(node: SpearNode): { total: number; transcendental: number } {
  let total = 0;
  let transcendental = 0;
  const walk = (nd: SpearNode) => {
    if (nd.op === "var" || nd.op === "const") return;
    total++;
    if (!ALGEBRAIC_OPS.has(nd.op)) transcendental++;
    nd.children.forEach(walk);
  };
  walk(node);
  return { total, transcendental };
}

// ------------------------------------------------------- canonical cache key
export function canonicalKey(node: SpearNode): string {
  const walk = (nd: SpearNode): string => {
    if (nd.op === "var") return `v:${nd.name}`;
    if (nd.op === "const") return `c:${roundConst(nd.value)}`;
    return `${nd.op}(${nd.children.map(walk).join(",")})`;
  };
  return walk(node);
}

// ---------------------------------------------------------------- simplify
function isConst(n: SpearNode, v?: number): boolean {
  return n.op === "const" && (v === undefined || roundConst(n.value) === roundConst(v));
}

export function simplify(node: SpearNode): SpearNode {
  const kids = node.children.map(simplify);
  // constant folding
  if (node.op !== "const" && node.op !== "var" && kids.every((k) => k.op === "const")) {
    const scope: Record<string, number> = {};
    const folded = evaluateScalar(makeNode(node.op, { value: node.value, children: kids }), scope);
    if (Number.isFinite(folded)) return makeNode("const", { value: roundConst(folded) });
  }
  switch (node.op) {
    case "add":
      if (isConst(kids[0], 0)) return kids[1];
      if (isConst(kids[1], 0)) return kids[0];
      if (kids[0].op === "const" && kids[1].op === "const") return makeNode("const", { value: roundConst(kids[0].value + kids[1].value) });
      break;
    case "sub":
      if (isConst(kids[1], 0)) return kids[0];
      if (isConst(kids[0], 0)) return simplify(makeNode("neg", { children: [kids[1]] }));
      break;
    case "mul":
      if (isConst(kids[0], 0) || isConst(kids[1], 0)) return makeNode("const", { value: 0 });
      if (isConst(kids[0], 1)) return kids[1];
      if (isConst(kids[1], 1)) return kids[0];
      if (isConst(kids[0], -1)) return simplify(makeNode("neg", { children: [kids[1]] }));
      if (isConst(kids[1], -1)) return simplify(makeNode("neg", { children: [kids[0]] }));
      if (kids[0].op === "sq" && kids[0].children[0] === kids[1]) return makeNode("cube", { children: [kids[1]] });
      break;
    case "pdiv":
      if (isConst(kids[1], 1)) return kids[0];
      if (isConst(kids[0], 0)) return makeNode("const", { value: 0 });
      break;
    case "neg":
      if (kids[0].op === "neg") return kids[0].children[0];
      if (kids[0].op === "const") return makeNode("const", { value: roundConst(-kids[0].value) });
      break;
    case "abs":
      if (kids[0].op === "abs" || kids[0].op === "sq") return kids[0];
      break;
    case "relu":
      if (kids[0].op === "relu") return kids[0];
      break;
    case "sq":
      if (kids[0].op === "abs") return makeNode("sq", { children: [kids[0].children[0]] });
      if (kids[0].op === "sqrt") return kids[0].children[0];
      break;
    case "max":
    case "min":
      if (canonicalKey(kids[0]) === canonicalKey(kids[1])) return kids[0];
      break;
    default: break;
  }
  if (
    (node.op === "add" || node.op === "mul" || node.op === "max" || node.op === "min") &&
    canonicalKey(kids[0]) === canonicalKey(kids[1])
  ) {
    if (node.op === "add") return makeNode("mul", { children: [makeNode("const", { value: 2 }), kids[0]] });
    if (node.op === "mul") return makeNode("sq", { children: [kids[0]] });
    return kids[0];
  }
  return makeNode(node.op, { value: node.value, name: node.name, children: kids });
}

// ------------------------------------------------------------ affine wrapper
export function wrapAffine(node: SpearNode, a: number, b: number): SpearNode {
  return simplify(
    makeNode("add", {
      children: [makeNode("mul", { children: [makeNode("const", { value: a }), node] }), makeNode("const", { value: b })],
    }),
  );
}

/** Least-squares fit of a·p + b onto target (Keijzer linear scaling). */
export function fitLinearScaling(pred: Float64Array, target: Float64Array): { a: number; b: number } {
  const n = pred.length;
  let sp = 0, st = 0, spp = 0, spt = 0;
  for (let i = 0; i < n; i++) { sp += pred[i]; st += target[i]; spp += pred[i] * pred[i]; spt += pred[i] * target[i]; }
  const denom = n * spp - sp * sp;
  if (Math.abs(denom) < 1e-12) return { a: 0, b: st / n };
  const a = (n * spt - sp * st) / denom;
  const b = (st - a * sp) / n;
  return { a, b };
}

export function countConstants(node: SpearNode): number {
  let c = node.op === "const" ? 1 : 0;
  for (const k of node.children) c += countConstants(k);
  return c;
}

/** Coordinate-descent refinement of every constant in the tree. */
export function refineConstants(
  node: SpearNode,
  score: (candidate: SpearNode) => number,
  budget = 40,
): { node: SpearNode; score: number; evals: number } {
  let best = cloneNode(node);
  let bestScore = score(best);
  let evals = 1;
  const positions: SpearNode[] = [];
  const collect = (nd: SpearNode) => {
    if (nd.op === "const") positions.push(nd);
    nd.children.forEach(collect);
  };
  collect(best);
  if (positions.length === 0 || !Number.isFinite(bestScore)) {
    return { node: best, score: bestScore, evals };
  }

  const writeAt = (idx: number, value: number) => { positions[idx].value = roundConst(value); };

  for (let round = 0; round < 6 && evals < budget; round++) {
    let improved = false;
    for (let i = 0; i < positions.length && evals < budget; i++) {
      const original = positions[i].value;
      const scale = Math.max(0.05, Math.abs(original) * 0.5);
      const steps = [scale, scale * 0.3, scale * 0.08, 0.02, 0.005, 0.001];
      for (const step of steps) {
        if (evals >= budget) break;
        for (const dir of [1, -1]) {
          if (evals >= budget) break;
          writeAt(i, original + dir * step);
          const s = score(best);
          evals++;
          if (Number.isFinite(s) && s < bestScore - 1e-12) {
            bestScore = s;
            improved = true;
            break;
          }
          writeAt(i, original);
        }
        if (improved) break;
      }
    }
    if (!improved) break;
  }
  // final cleanup: fold trivial constants
  const cleaned = simplify(best);
  const cleanedScore = score(cleaned);
  evals++;
  return {
    node: Number.isFinite(cleanedScore) && cleanedScore <= bestScore ? cleaned : best,
    score: Math.min(cleanedScore, bestScore),
    evals,
  };
}

// ---------------------------------------------------------------- GP config
export interface GpConfig {
  variables: string[];
  constRange: [number, number];
  ops: NodeOp[];
  maxDepth: number;
  terminalVarProb?: number;
}

export function randomTree(cfg: GpConfig, maxDepth: number): SpearNode {
  const termProb = cfg.terminalVarProb ?? 0.65;
  if (maxDepth <= 1 || (maxDepth < cfg.maxDepth && rand() < 0.25)) {
    if (cfg.variables.length > 0 && rand() < termProb) {
      return makeNode("var", { name: pick(cfg.variables) });
    }
    return makeNode("const", { value: roundConst(randRange(cfg.constRange[0], cfg.constRange[1])) });
  }
  const op = pick(cfg.ops);
  const ar = arity(op);
  const children = Array.from({ length: ar }, () => randomTree(cfg, maxDepth - 1));
  return makeNode(op, { children });
}

function collectNodes(node: SpearNode): SpearNode[] {
  const res: SpearNode[] = [node];
  for (const c of node.children) res.push(...collectNodes(c));
  return res;
}

function replaceNode(root: SpearNode, target: SpearNode, replacement: SpearNode): SpearNode {
  if (root === target) return replacement;
  if (root.children.length === 0) return root;
  return makeNode(root.op, {
    value: root.value,
    name: root.name,
    children: root.children.map((c) => replaceNode(c, target, replacement)),
  });
}

export function crossover(p1: SpearNode, p2: SpearNode, maxDepth: number): SpearNode {
  const n1 = collectNodes(p1);
  const n2 = collectNodes(p2);
  const child = replaceNode(p1, pick(n1), pick(n2));
  return child.depth <= maxDepth ? child : p1;
}

export function mutate(p: SpearNode, cfg: GpConfig): SpearNode {
  const nodes = collectNodes(p);
  const target = pick(nodes);
  let replacement: SpearNode;
  if (target.op === "const") {
    replacement = makeNode("const", { value: roundConst(target.value + (rand() * 2 - 1) * Math.max(0.05, Math.abs(target.value) * 0.4)) });
  } else if (target.op === "var") {
    if (cfg.variables.length > 1 && rand() < 0.5) {
      const others = cfg.variables.filter((v) => v !== target.name);
      replacement = makeNode("var", { name: pick(others) });
    } else {
      replacement = randomTree(cfg, 2);
    }
  } else {
    const ar = arity(target.op);
    const same = cfg.ops.filter((o) => arity(o) === ar);
    if (same.length > 0 && rand() < 0.6) {
      replacement = makeNode(pick(same), { children: target.children });
    } else {
      replacement = randomTree(cfg, Math.max(1, cfg.maxDepth - 1));
    }
  }
  const mutated = simplify(replaceNode(p, target, replacement));
  return mutated.depth <= cfg.maxDepth ? mutated : p;
}

/** Fine-tune a single constant by a small delta. Preserves structure. */
export function mutatePolish(p: SpearNode, step = 0.08): SpearNode {
  const consts: SpearNode[] = [];
  const collect = (nd: SpearNode) => {
    if (nd.op === "const") consts.push(nd);
    nd.children.forEach(collect);
  };
  collect(p);
  if (consts.length === 0) return p;
  const target = pick(consts);
  const delta = (rand() < 0.5 ? -1 : 1) * step * (1 + rand());
  return simplify(replaceNode(p, target, makeNode("const", { value: roundConst(target.value + delta) })));
}

/** Swap a constant with a small algebraic expression, or vice versa. */
export function mutateStructure(p: SpearNode, cfg: GpConfig): SpearNode {
  const nodes = collectNodes(p);
  const target = pick(nodes);
  if (target.op === "const") {
    // promote constant → tiny expression
    const tiny = pick(cfg.variables);
    const rep = rand() < 0.5
      ? makeNode("mul", { children: [makeNode("const", { value: roundConst(target.value) }), makeNode("var", { name: tiny })] })
      : makeNode("add", { children: [makeNode("var", { name: tiny }), makeNode("const", { value: roundConst(target.value) })] });
    const m = simplify(replaceNode(p, target, rep));
    return m.depth <= cfg.maxDepth ? m : p;
  }
  if (target.op !== "var" && target.children.length > 0 && target.children.every((c) => c.op === "const" || c.op === "var")) {
    // demote a small subexpression → constant equal to its evaluation at 0
    const scope: Record<string, number> = {};
    const folded = evaluateScalar(target, scope);
    if (Number.isFinite(folded)) {
      const m = simplify(replaceNode(p, target, makeNode("const", { value: roundConst(folded) })));
      return m.depth <= cfg.maxDepth ? m : p;
    }
  }
  return p;
}

// ---------------------------------------------------------------- NSGA-II
export interface ObjectiveVector {
  /** primary objective, higher is better after internal normalisation */
  fitness: number;
  /** parsimony: smaller is better */
  size: number;
}

export function dominates(a: ObjectiveVector, b: ObjectiveVector): boolean {
  const aFit = Number.isFinite(a.fitness);
  const bFit = Number.isFinite(b.fitness);
  if (!aFit) return false;
  if (!bFit) return true;
  return (a.fitness >= b.fitness && a.size <= b.size) && (a.fitness > b.fitness || a.size < b.size);
}

export function nonDominatedSort(pop: ObjectiveVector[]): number[] {
  const n = pop.length;
  const domCount = new Array(n).fill(0);
  const ranks = new Array(n).fill(0);
  const fronts: number[][] = [[]];
  for (let p = 0; p < n; p++) {
    for (let q = 0; q < n; q++) {
      if (p === q) continue;
      if (dominates(pop[p], pop[q])) domCount[q]++;
    }
  }
  for (let i = 0; i < n; i++) if (domCount[i] === 0) { ranks[i] = 0; fronts[0].push(i); }
  let f = 0;
  while (fronts[f] && fronts[f].length > 0) {
    const next: number[] = [];
    for (const i of fronts[f]) {
      for (let q = 0; q < n; q++) {
        if (dominates(pop[i], pop[q])) {
          domCount[q]--;
          if (domCount[q] === 0) { ranks[q] = f + 1; next.push(q); }
        }
      }
    }
    f++;
    fronts[f] = next;
  }
  return ranks;
}

export function crowdingDistance(front: ObjectiveVector[]): number[] {
  const n = front.length;
  const dist = new Array(n).fill(0);
  if (n <= 2) return front.map(() => Infinity);
  for (const key of ["fitness", "size"] as const) {
    const order = front.map((v, i) => ({ i, v: v[key] })).sort((a, b) => a.v - b.v);
    dist[order[0].i] = Infinity;
    dist[order[n - 1].i] = Infinity;
    const span = order[n - 1].v - order[0].v || 1;
    for (let k = 1; k < n - 1; k++) dist[order[k].i] += (order[k + 1].v - order[k - 1].v) / span;
  }
  return dist;
}

export function tournamentSelect(pop: ObjectiveVector[]): number {
  const a = randInt(pop.length);
  const b = randInt(pop.length);
  const rA = pop[a];
  const rB = pop[b];
  if (rA.fitness !== rB.fitness) {
    if (!Number.isFinite(rB.fitness)) return a;
    if (!Number.isFinite(rA.fitness)) return b;
    return rA.fitness > rB.fitness ? a : b;
  }
  if (rA.size !== rB.size) return rA.size < rB.size ? a : b;
  return rand() < 0.5 ? a : b;
}

// ---------------------------------------------------------------- evolution
export interface FitnessResult extends ObjectiveVector {
  extra?: number;
}

export type FitnessFn = (node: SpearNode) => FitnessResult;

export interface EvolveConfig extends GpConfig {
  populationSize: number;
  generations: number;
  crossoverRate?: number;
  mutationRate?: number;
}

export interface GenerationRecord {
  generation: number;
  bestFitness: number;
  bestSize: number;
  bestExtra?: number;
}

export interface EvolveResult {
  best: SpearNode;
  bestFitness: number;
  bestExtra?: number;
  front: SpearNode[];
  history: GenerationRecord[];
  durationMs: number;
  evals: number;
}

export function evolve(cfg: EvolveConfig, fitnessFn: FitnessFn): EvolveResult {
  const t0 = Date.now();
  let population = Array.from({ length: cfg.populationSize }, () => simplify(randomTree(cfg, cfg.maxDepth)));
  const archive = new Map<string, { node: SpearNode; obj: FitnessResult }>();
  let best: SpearNode = population[0];
  let bestFitness = -Infinity;
  let bestExtra: number | undefined;
  const history: GenerationRecord[] = [];
  let evals = 0;
  const crossoverRate = cfg.crossoverRate ?? 0.8;
  const mutationRate = cfg.mutationRate ?? 0.35;

  for (let gen = 0; gen < cfg.generations; gen++) {
    const results = population.map((ind) => {
      evals++;
      return fitnessFn(ind);
    });
    const objs = results.map((r) => ({ fitness: r.fitness, size: r.size }));

    for (let i = 0; i < population.length; i++) {
      const key = canonicalKey(population[i]);
      const prev = archive.get(key);
      if (!prev || results[i].fitness > prev.obj.fitness) {
        archive.set(key, { node: population[i], obj: results[i] });
      }
    }

    let genBest = 0;
    for (let i = 1; i < population.length; i++) if (results[i].fitness > results[genBest].fitness) genBest = i;
    if (results[genBest].fitness > bestFitness) {
      bestFitness = results[genBest].fitness;
      best = population[genBest];
      bestExtra = results[genBest].extra;
    }
    history.push({
      generation: gen,
      bestFitness: Number.isFinite(bestFitness) ? bestFitness : -1e9,
      bestSize: best.size,
      bestExtra,
    });

    const ranks = nonDominatedSort(objs);
    const maxRank = Math.max(...ranks);
    const byFront: number[][] = Array.from({ length: maxRank + 1 }, () => []);
    for (let i = 0; i < population.length; i++) byFront[ranks[i]].push(i);

    const selected: number[] = [];
    for (const front of byFront) {
      if (front.length === 0) continue;
      if (selected.length + front.length <= cfg.populationSize) {
        selected.push(...front);
        continue;
      }
      const frontObjs = front.map((i) => objs[i]);
      const dist = crowdingDistance(frontObjs);
      const order = front.map((i, k) => ({ i, d: dist[k] })).sort((a, b) => b.d - a.d);
      for (const { i } of order) {
        if (selected.length >= cfg.populationSize) break;
        selected.push(i);
      }
      break;
    }

    const newPop: SpearNode[] = [best];
    while (newPop.length < cfg.populationSize) {
      const p1 = population[tournamentSelect(objs)];
      let child: SpearNode;
      if (rand() < crossoverRate) {
        const p2 = population[tournamentSelect(objs)];
        child = crossover(p1, p2, cfg.maxDepth);
      } else {
        child = p1;
      }
      if (rand() < mutationRate) child = mutate(child, cfg);
      child = simplify(child);
      if (child.depth <= cfg.maxDepth) newPop.push(child);
    }
    population = newPop;
  }

  const frontObjs = population.map((p) => fitnessFn(p));
  const ranksFinal = nonDominatedSort(frontObjs.map((r) => ({ fitness: r.fitness, size: r.size })));
  const frontIdx = population.filter((_, i) => ranksFinal[i] === 0);
  evals += population.length;

  const archiveFront = [...archive.values()]
    .filter((e) => Number.isFinite(e.obj.fitness))
    .sort((a, b) => b.obj.fitness - a.obj.fitness)
    .slice(0, 8)
    .map((e) => e.node);

  return {
    best,
    bestFitness,
    bestExtra,
    front: frontIdx.length > 0 ? frontIdx : archiveFront,
    history,
    durationMs: Date.now() - t0,
    evals,
  };
}
