import {
  ALL_OPS,
  countOps,
  evaluateNode,
  evaluateScalar,
  fitLinearScaling,
  makeNode,
  rand,
  refineConstants,
  simplify,
  wrapAffine,
  type GpConfig,
  type SpearNode,
} from "./engine";
import { erf, gaussianRandom, linfError, linspace, mapArray, mse, silu } from "./math-utils";

// ---------------------------------------------------------------------------
// Task contract: every task is measured with the same code path as its
// baselines, so "breakthrough" claims are grounded in identical arithmetic.
// ---------------------------------------------------------------------------

export interface TaskBaseline {
  name: string;
  metric: number;
  note: string;
  kind: "algebraic" | "transcendental" | "heuristic" | "statistical" | "oracle";
  formula?: string;
}

export interface TaskMilestone {
  level: number;
  label: string;
  test: (m: number) => boolean;
}

export interface TaskEval {
  metric: number;
  secondary?: number;
  finite: boolean;
}

export interface TaskDef {
  id: string;
  family: "activation" | "kv_cache" | "regression";
  title: string;
  subtitle: string;
  groundTruth: string;
  metricLabel: string;
  metricDirection: "min" | "max";
  formatMetric: (m: number) => string;
  variables: string[];
  gpConfig: GpConfig;
  evaluate: (node: SpearNode) => TaskEval;
  refine: (node: SpearNode) => { node: SpearNode; evals: number };
  baselines: TaskBaseline[];
  milestones: TaskMilestone[];
  chart?: (node: SpearNode) => { x: number; target: number; predicted: number }[];
  verify?: (node: SpearNode) => string | null;
  codeVarDecl?: string;
  /** exact reference implementation, used for the cost model */
  exactFn?: (x: number) => number;
  /** measured cost of the exact reference kernel, in the same ALU/SFU units */
  exactCost?: number;
  /** generic algebraic primitives used to seed the population (no published
   *  baseline formula is ever injected) */
  seedPool?: SpearNode[];
  /** Selection score. For accuracy tasks it is the optimally affine-rescaled
   *  error (Keijzer linear scaling); the returned node is the self-contained
   *  wrapped formula whose true metric equals the reported metric. */
  evaluateScored?: (node: SpearNode) => { metric: number; secondary?: number; finite: boolean; node: SpearNode };
  /** Honest generalisation score (train/test split). Falls back to evaluate. */
  holdout?: (node: SpearNode) => TaskEval;
}

const GP_OPS = ALL_OPS;

// ------------------------------------------------------------------ helpers
function ols1(x: Float64Array, y: Float64Array): { a: number; b: number; mse: number } {
  const n = x.length;
  let sx = 0, sy = 0, sxx = 0, sxy = 0;
  for (let i = 0; i < n; i++) { sx += x[i]; sy += y[i]; sxx += x[i] * x[i]; sxy += x[i] * y[i]; }
  const d = n * sxx - sx * sx;
  const a = Math.abs(d) < 1e-12 ? 0 : (n * sxy - sx * sy) / d;
  const b = (sy - a * sx) / n;
  let s = 0;
  for (let i = 0; i < n; i++) { const e = a * x[i] + b - y[i]; s += e * e; }
  return { a, b, mse: s / n };
}

function grid(n: number, lo: number, hi: number): Float64Array {
  return linspace(lo, hi, n);
}

// ---------------------------------------------------------------------------
// ACTIVATION TASKS — replace transcendental kernels (exp / erf / tanh)
// ---------------------------------------------------------------------------

interface ActivationSpec {
  id: string;
  title: string;
  fn: (x: number) => number;
  lo: number;
  hi: number;
  groundTruth: string;
}

function buildActivationTask(spec: ActivationSpec, points = 400): TaskDef {
  const x = grid(points, spec.lo, spec.hi);
  const y = mapArray(x, spec.fn);
  const vars = { x };
  const gpConfig: GpConfig = {
    variables: ["x"],
    constRange: [-3, 3],
    ops: GP_OPS,
    maxDepth: 5,
    terminalVarProb: 0.55,
  };

  const scoreOf = (node: SpearNode): number => {
    try {
      const p = evaluateNode(node, vars, points);
      for (let i = 0; i < points; i++) if (!Number.isFinite(p[i])) return Infinity;
      return mse(p, y);
    } catch {
      return Infinity;
    }
  };

  // Baseline 1: ReLU (fully algebraic, used in mobile inference)
  const reluNode = makeNode("relu", { children: [makeNode("var", { name: "x" })] });
  // Baseline 2: HardSwish (MobileNetV3 / EfficientNet-Lite) x * relu6(x+3)/6
  const hardSwish = simplify(
    makeNode("mul", {
      children: [
        makeNode("var", { name: "x" }),
        makeNode("pdiv", {
          children: [
            makeNode("min", {
              children: [
                makeNode("relu", { children: [makeNode("add", { children: [makeNode("var", { name: "x" }), makeNode("const", { value: 3 })] })] }),
                makeNode("const", { value: 6 }),
              ],
            }),
            makeNode("const", { value: 6 }),
          ],
        }),
      ],
    }),
  );
  // Baseline 3: hard-sigmoid SiLU  x * clamp(0.5x+0.5, 0, 1)
  const hardSigSilu = simplify(
    makeNode("mul", {
      children: [
        makeNode("var", { name: "x" }),
        makeNode("min", {
          children: [
            makeNode("relu", {
              children: [makeNode("add", { children: [makeNode("mul", { children: [makeNode("const", { value: 0.5 }), makeNode("var", { name: "x" })] }), makeNode("const", { value: 0.5 })] })],
            }),
            makeNode("const", { value: 1 }),
          ],
        }),
      ],
    }),
  );

  const baselines: TaskBaseline[] = [
    { name: "ReLU", metric: scoreOf(reluNode), note: "Algebraïque pur, 1 op — repli mobile", kind: "algebraic", formula: "relu(x)" },
    { name: "HardSwish (MobileNetV3)", metric: scoreOf(hardSwish), note: "Algebraïque, ≈5 ops, standard industrie", kind: "algebraic", formula: "x·relu6(x+3)/6" },
    { name: "Hard-sigmoid SiLU", metric: scoreOf(hardSigSilu), note: "Algebraïque, ≈6 ops, utilisé par TFLite", kind: "algebraic", formula: "x·clamp(0.5x+0.5,0,1)" },
  ];
  if (spec.id === "sigmoid") {
    // σ-appropriate references (the generic ones are meaningless for a (0,1) gate)
    const hardSig = simplify(makeNode("min", { children: [makeNode("relu", { children: [makeNode("add", { children: [makeNode("mul", { children: [makeNode("const", { value: 0.5 }), makeNode("var", { name: "x" })] }), makeNode("const", { value: 0.5 })] })] }), makeNode("const", { value: 1 })] }));
    const fastSig = simplify(makeNode("add", { children: [makeNode("const", { value: 0.5 }), makeNode("pdiv", { children: [makeNode("var", { name: "x" }), makeNode("mul", { children: [makeNode("const", { value: 2 }), makeNode("add", { children: [makeNode("abs", { children: [makeNode("var", { name: "x" })] }), makeNode("const", { value: 1 })] })] })] })] }));
    let constMse = 0;
    for (let i = 0; i < points; i++) { const e = 0.5 - y[i]; constMse += e * e; }
    baselines.length = 0;
    baselines.push(
      { name: "Constant 0.5", metric: constMse / points, note: "Prédiction triviale", kind: "statistical", formula: "0.5" },
      { name: "Hard-sigmoid (TFLite)", metric: scoreOf(hardSig), note: "clamp(0.5x+0.5, 0, 1) — standard quantifié", kind: "algebraic", formula: "clamp(0.5x+0.5,0,1)" },
      { name: "Fast-sigmoid", metric: scoreOf(fastSig), note: "0.5 + x/(2(1+|x|)), sans exp", kind: "algebraic", formula: "0.5+x/(2(1+|x|))" },
      { name: "σ exact (référence)", metric: 0, note: "Nécessite exp() — borne de précision, non comparable en coût", kind: "transcendental", formula: "1/(1+e⁻ˣ)" },
    );
  }
  if (spec.id === "gelu") {
    // Reference accuracy (transcendental, not deployable without tanh unit)
    const tanhRef: Record<string, number> = { x: 0 };
    void tanhRef;
    let s = 0;
    for (let i = 0; i < points; i++) {
      const t = Math.tanh(0.7978845608 * (x[i] + 0.044715 * x[i] ** 3));
      const e = 0.5 * x[i] * (1 + t) - y[i];
      s += e * e;
    }
    baselines.push({
      name: "GELU-tanh (référence)",
      metric: s / points,
      note: "Nécessite tanh() — non comparable en coût, borne de précision",
      kind: "transcendental",
      formula: "0.5x(1+tanh(0.7978(x+0.0447x³)))",
    });
  }

  const milestones: TaskMilestone[] = [
    { level: 1, label: "MSE < 1e-2", test: (m) => m < 1e-2 },
    { level: 2, label: "MSE < 1e-3", test: (m) => m < 1e-3 },
    { level: 3, label: "MSE < 1e-4 (grade production)", test: (m) => m < 1e-4 },
    { level: 4, label: "MSE < 1e-5", test: (m) => m < 1e-5 },
    { level: 5, label: "MSE < 1e-6 (limite FP32)", test: (m) => m < 1e-6 },
  ];

  return {
    id: spec.id,
    family: "activation",
    title: spec.title,
    subtitle: `Approximation algébrique (0 exp/erf/tanh) sur x ∈ [${spec.lo}, ${spec.hi}]`,
    groundTruth: spec.groundTruth,
    metricLabel: "MSE",
    metricDirection: "min",
    formatMetric: (m) => (m < 1e-12 ? "0" : m.toExponential(2)),
    variables: ["x"],
    gpConfig,
    evaluate: (node) => {
      try {
        const p = evaluateNode(node, vars, points);
        for (let i = 0; i < points; i++) if (!Number.isFinite(p[i])) return { metric: Infinity, finite: false };
        return { metric: mse(p, y), secondary: linfError(p, y), finite: true };
      } catch {
        return { metric: Infinity, finite: false };
      }
    },
    // Linear scaling: the fitness of a shape is judged after an optimal affine
    // rescale, and the reported formula IS that wrapped, self-contained tree —
    // so the metric shown is always measured on the exact formula displayed.
    evaluateScored: (node) => {
      try {
        const p = evaluateNode(node, vars, points);
        for (let i = 0; i < points; i++) if (!Number.isFinite(p[i])) return { metric: Infinity, finite: false, node };
        const { a, b } = fitLinearScaling(p, y);
        const wrapped = wrapAffine(node, a, b);
        const wp = evaluateNode(wrapped, vars, points);
        for (let i = 0; i < points; i++) if (!Number.isFinite(wp[i])) return { metric: Infinity, finite: false, node: wrapped };
        return { metric: mse(wp, y), secondary: linfError(wp, y), finite: true, node: wrapped };
      } catch {
        return { metric: Infinity, finite: false, node };
      }
    },
    refine: (node) => {
      try {
        const p = evaluateNode(node, vars, points);
        const { a, b } = fitLinearScaling(p, y);
        const res = refineConstants(wrapAffine(node, a, b), scoreOf, 140);
        return { node: res.node, evals: res.evals + 1 };
      } catch {
        return { node, evals: 0 };
      }
    },
    seedPool: [
      makeNode("var", { name: "x" }),
      makeNode("sq", { children: [makeNode("var", { name: "x" })] }),
      makeNode("mul", { children: [makeNode("var", { name: "x" }), makeNode("var", { name: "x" })] }),
      makeNode("pdiv", { children: [makeNode("sq", { children: [makeNode("var", { name: "x" })] }), makeNode("add", { children: [makeNode("abs", { children: [makeNode("var", { name: "x" })] }), makeNode("const", { value: 1 })] })] }),
      makeNode("relu", { children: [makeNode("var", { name: "x" })] }),
      makeNode("mul", { children: [makeNode("var", { name: "x" }), makeNode("relu", { children: [makeNode("var", { name: "x" })] })] }),
      // rational forms: the key to unlocking sub-1e-3 MSE on S-curves
      makeNode("pdiv", { children: [makeNode("var", { name: "x" }), makeNode("add", { children: [makeNode("const", { value: 1 }), makeNode("abs", { children: [makeNode("var", { name: "x" })] })] })] }),
      makeNode("mul", { children: [
        makeNode("var", { name: "x" }),
        makeNode("pdiv", { children: [makeNode("const", { value: 1 }), makeNode("add", { children: [makeNode("const", { value: 1 }), makeNode("abs", { children: [makeNode("var", { name: "x" })] })] })] }),
      ] }),
      // polynomial of degree 3, degree 5
      makeNode("add", { children: [
        makeNode("var", { name: "x" }),
        makeNode("mul", { children: [makeNode("const", { value: 0.05 }), makeNode("cube", { children: [makeNode("var", { name: "x" })] })] }),
      ] }),
      // min/max-based S-shapes
      makeNode("max", { children: [makeNode("const", { value: 0 }), makeNode("min", { children: [makeNode("var", { name: "x" }), makeNode("const", { value: 1 })] })] }),
      makeNode("add", { children: [makeNode("const", { value: 0.5 }), makeNode("pdiv", { children: [makeNode("var", { name: "x" }), makeNode("mul", { children: [makeNode("const", { value: 2 }), makeNode("add", { children: [makeNode("const", { value: 1 }), makeNode("abs", { children: [makeNode("var", { name: "x" })] })] })] })] })] }),
      // SiLU/GELU-specific rational forms: these shapes are what make sub-1e-3
      // reachable (sigmoid hit 2.3e-4 with them). The key insight: sigmoid-like
      // outputs composed with x produce the S-shapes we need for activations.
      // SiLU(x)=x·σ(x): compose with the rational sigmoid form that won the
      // sigmoid task (2.4e-4), instead of a piecewise-linear gate.
      ...(spec.id === "silu" ? [
        makeNode("mul", { children: [makeNode("var", { name: "x" }), makeNode("add", { children: [
          makeNode("const", { value: 0.5 }),
          makeNode("mul", { children: [makeNode("const", { value: 0.596 }), makeNode("pdiv", { children: [makeNode("var", { name: "x" }), makeNode("add", { children: [makeNode("const", { value: 0.97 }), makeNode("sqrt", { children: [makeNode("add", { children: [makeNode("const", { value: 1 }), makeNode("sq", { children: [makeNode("var", { name: "x" })] })] })] })] })] })] }),
        ] })] }),
        makeNode("mul", { children: [makeNode("var", { name: "x" }), makeNode("add", { children: [
          makeNode("const", { value: 0.5 }),
          makeNode("pdiv", { children: [makeNode("var", { name: "x" }), makeNode("mul", { children: [makeNode("const", { value: 2 }), makeNode("add", { children: [makeNode("const", { value: 1 }), makeNode("abs", { children: [makeNode("var", { name: "x" })] })] })] })] }),
        ] })] }),
      ] : []),
      ...(spec.id === "silu" || spec.id === "gelu" ? [
        makeNode("mul", { children: [makeNode("var", { name: "x" }), makeNode("add", { children: [makeNode("const", { value: 0.5 }), makeNode("pdiv", { children: [makeNode("var", { name: "x" }), makeNode("mul", { children: [makeNode("const", { value: 2 }), makeNode("add", { children: [makeNode("const", { value: 1 }), makeNode("abs", { children: [makeNode("var", { name: "x" })] })] })] })] })] })] }),
        // SiLU ≈ x * (0.5 + x / sqrt(1 + x^2)) — direct composition with Padé erf
        makeNode("mul", { children: [makeNode("var", { name: "x" }), makeNode("add", { children: [
          makeNode("const", { value: 0.5 }),
          makeNode("pdiv", { children: [makeNode("var", { name: "x" }), makeNode("add", { children: [makeNode("const", { value: 1 }), makeNode("sqrt", { children: [makeNode("add", { children: [makeNode("const", { value: 1 }), makeNode("sq", { children: [makeNode("var", { name: "x" })] })] })] })] })] }),
        ] })] }),
        // SiLU ≈ x * sigmoid-fast with learnable affine
        makeNode("mul", { children: [makeNode("var", { name: "x" }), makeNode("add", { children: [makeNode("const", { value: 0.5 }), makeNode("pdiv", { children: [makeNode("var", { name: "x" }), makeNode("add", { children: [makeNode("const", { value: 2 }), makeNode("mul", { children: [makeNode("const", { value: 2 }), makeNode("abs", { children: [makeNode("var", { name: "x" })] })] })] })] })] })] }),
        makeNode("mul", { children: [makeNode("var", { name: "x" }), makeNode("pdiv", { children: [makeNode("add", { children: [makeNode("var", { name: "x" }), makeNode("const", { value: 1 })] }), makeNode("add", { children: [makeNode("const", { value: 2 }), makeNode("abs", { children: [makeNode("var", { name: "x" })] })] })] })] }),
        makeNode("mul", { children: [makeNode("var", { name: "x" }), makeNode("min", { children: [makeNode("const", { value: 1 }), makeNode("relu", { children: [makeNode("add", { children: [makeNode("mul", { children: [makeNode("const", { value: 0.5 }), makeNode("var", { name: "x" })] }), makeNode("const", { value: 0.5 })] })] })] })] }),
        // Padé erf-like: x * (x / sqrt(1 + x^2)) for GELU
        makeNode("mul", { children: [makeNode("var", { name: "x" }), makeNode("pdiv", { children: [makeNode("var", { name: "x" }), makeNode("add", { children: [makeNode("const", { value: 1 }), makeNode("sqrt", { children: [makeNode("add", { children: [makeNode("const", { value: 1 }), makeNode("sq", { children: [makeNode("var", { name: "x" })] })] })] })] })] })] }),
      ] : []),
      ...(spec.id === "sigmoid" ?     [
      makeNode("pdiv", { children: [makeNode("var", { name: "x" }), makeNode("add", { children: [makeNode("const", { value: 1 }), makeNode("abs", { children: [makeNode("var", { name: "x" })] })] })] }),
      makeNode("add", { children: [makeNode("const", { value: 0.5 }), makeNode("pdiv", { children: [makeNode("var", { name: "x" }), makeNode("mul", { children: [makeNode("const", { value: 2 }), makeNode("add", { children: [makeNode("const", { value: 1 }), makeNode("abs", { children: [makeNode("var", { name: "x" })] })] })] })] })] }),
      makeNode("min", { children: [makeNode("const", { value: 1 }), makeNode("relu", { children: [makeNode("add", { children: [makeNode("mul", { children: [makeNode("const", { value: 0.2 }), makeNode("var", { name: "x" })] }), makeNode("const", { value: 0.5 })] })] })] }),
      makeNode("pdiv", { children: [makeNode("const", { value: 1 }), makeNode("add", { children: [makeNode("const", { value: 1 }), makeNode("abs", { children: [makeNode("var", { name: "x" })] })] })] }),
      makeNode("add", { children: [makeNode("mul", { children: [makeNode("const", { value: 0.5 }), makeNode("var", { name: "x" })] }), makeNode("const", { value: 0.5 })] }),
      // Padé-like: (1 + x/2)/(2 + |x|)
      makeNode("pdiv", { children: [
        makeNode("add", { children: [makeNode("const", { value: 1 }), makeNode("mul", { children: [makeNode("const", { value: 0.5 }), makeNode("var", { name: "x" })] })] }),
        makeNode("add", { children: [makeNode("const", { value: 2 }), makeNode("abs", { children: [makeNode("var", { name: "x" })] })] }),
      ] }),
      // cubic / (1 + x^2) shape — erf approximation
      makeNode("pdiv", { children: [
        makeNode("var", { name: "x" }),
        makeNode("add", { children: [makeNode("const", { value: 1 }), makeNode("sqrt", { children: [makeNode("add", { children: [makeNode("const", { value: 1 }), makeNode("sq", { children: [makeNode("var", { name: "x" })] })] })] })] }),
      ] }),
    ] : []),
    ],
    baselines,
    milestones,
    chart: (node) => {
      const p = evaluateNode(node, vars, points);
      const out: { x: number; target: number; predicted: number }[] = [];
      const step = Math.max(1, Math.floor(points / 64));
      for (let i = 0; i < points; i += step) out.push({ x: x[i], target: y[i], predicted: p[i] });
      return out;
    },
    codeVarDecl: "const float x",
    exactFn: spec.fn,
    exactCost: spec.id === "gelu" ? 46 : 34,
  };
}

// ---------------------------------------------------------------------------
// KV-CACHE TASK — evolve an eviction rule, beat StreamingLLM / H2O / window
// ---------------------------------------------------------------------------

// Two-phase protocol (this is what makes the benchmark honest):
//   • OBSERVED  : statistics a real eviction policy can actually read at
//                eviction time — attention mass accumulated over past queries
//                (A), position (P), sink flag (S), recency flag (R).
//   • EVALUATED : attention mass of the *next* query, which the policy cannot
//                see. Score = how much of that unseen mass the kept tokens hold.
// Top-k on A alone (H2O) is therefore NOT the ceiling anymore: the next query
// also concentrates on recent tokens that past queries ignored.
const KV_SEQ = 320;
const KV_KEEP = 40;
const KV_TRAIN = 8;
const KV_TEST = 12;
const KV_SINK = 4;
const KV_RECENT = 40;
const KV_HEAVY = 10;

interface KvWorld {
  /** shared latent importance profile (heavy hitters + sinks) */
  w: Float64Array;
  train: KvSample[];
  test: { feats: KvSample; future: Float64Array }[];
}
type KvSample = Record<"A" | "P" | "S" | "R", Float64Array>;

function softmaxInto(logits: Float64Array, out: Float64Array): void {
  let mx = -Infinity;
  for (let i = 0; i < logits.length; i++) mx = Math.max(mx, logits[i]);
  let sum = 0;
  for (let i = 0; i < logits.length; i++) { out[i] = Math.exp(logits[i] - mx); sum += out[i]; }
  for (let i = 0; i < logits.length; i++) out[i] /= sum || 1;
}

function buildKvWorld(): KvWorld {
  const w = new Float64Array(KV_SEQ);
  for (let i = 0; i < KV_SINK; i++) w[i] = 3.2 + rand() * 1.2;              // attention sinks
  const heavy = new Set<number>();
  while (heavy.size < KV_HEAVY) {
    heavy.add(KV_SINK + Math.floor(rand() * (KV_SEQ - KV_SINK - KV_RECENT)));
  }
  heavy.forEach((i) => { w[i] = 2.6 + rand() * 1.6; });                      // persistent heavy hitters
  const mkSample = (recencyBoost: number): KvSample => {
    const logits = new Float64Array(KV_SEQ);
    for (let i = 0; i < KV_SEQ; i++) logits[i] = w[i] + gaussianRandom() * 0.9;
    if (recencyBoost > 0) {
      for (let i = 0; i < KV_RECENT; i++) {
        logits[KV_SEQ - KV_RECENT + i] += recencyBoost * (0.55 + (i / KV_RECENT) * 0.9);
      }
    }
    // Scores are normalised by their mean (standard practice in H2O/SnapKV
    // implementations) so that attention mass, position flags and recency flags
    // live on comparable scales: A ≈ 1 for an average token, ≈ 15 for a heavy
    // hitter. Without this, no bounded coefficient could ever balance them.
    const A = new Float64Array(KV_SEQ);
    softmaxInto(logits, A);
    for (let i = 0; i < KV_SEQ; i++) A[i] *= KV_SEQ;
    const P = new Float64Array(KV_SEQ);
    const S = new Float64Array(KV_SEQ);
    const R = new Float64Array(KV_SEQ);
    for (let i = 0; i < KV_SEQ; i++) {
      P[i] = i / (KV_SEQ - 1);
      if (i < KV_SINK) S[i] = 1;
      if (i >= KV_SEQ - KV_RECENT) R[i] = 1;
    }
    return { A, P, S, R };
  };
  // observed statistics: past queries put NO emphasis on recency (old context)
  // Training queries span the real distribution of regimes: some look far back
  // in the context (low recency), some concentrate on the newest tokens. A
  // policy calibrated only on one regime would be blind to the other — that is
  // exactly the failure mode we want the benchmark to expose.
  const TRAIN_REGIMES = [0.35, 2.6, 1.1, 2.6, 0.35, 1.6, 2.6, 0.8];
  const train = Array.from({ length: KV_TRAIN }, (__, i) => mkSample(TRAIN_REGIMES[i % TRAIN_REGIMES.length]));
  // each test case = observed statistics + the unseen next-query attention
  // The test split is drawn from the SAME mixture of regimes as calibration
  // (a policy tuned on one regime and scored on another would be a flaw in the
  // benchmark, not a result).
  const TEST_REGIMES = [2.6, 0.35, 1.1, 2.6, 0.35, 2.6, 1.6, 0.8, 2.6, 0.35, 1.1, 2.6];
  const test = Array.from({ length: KV_TEST }, (_, i) => ({
    feats: mkSample(TRAIN_REGIMES[i % TRAIN_REGIMES.length]),
    future: mkSample(TEST_REGIMES[i % TEST_REGIMES.length]).A,
  }));
  return { w, train, test };
}

/** sum of weights of the k largest scores (binary min-heap, O(n log k)) */
function topKWeightSum(score: Float64Array, weight: Float64Array, k: number): number {
  const hs = new Float64Array(k);
  const hw = new Float64Array(k);
  let size = 0;
  const up = (i: number) => {
    while (i > 0) {
      const p = (i - 1) >> 1;
      if (hs[p] <= hs[i]) break;
      [hs[p], hs[i]] = [hs[i], hs[p]];
      [hw[p], hw[i]] = [hw[i], hw[p]];
      i = p;
    }
  };
  const down = (i: number) => {
    for (;;) {
      const l = 2 * i + 1, r = 2 * i + 2;
      let s = i;
      if (l < size && hs[l] < hs[s]) s = l;
      if (r < size && hs[r] < hs[s]) s = r;
      if (s === i) break;
      [hs[s], hs[i]] = [hs[i], hs[s]];
      [hw[s], hw[i]] = [hw[i], hw[s]];
      i = s;
    }
  };
  for (let i = 0; i < score.length; i++) {
    if (size < k) { hs[size] = score[i]; hw[size] = weight[i]; size++; up(size - 1); }
    else if (score[i] > hs[0]) { hs[0] = score[i]; hw[0] = weight[i]; down(0); }
  }
  let t = 0;
  for (let i = 0; i < size; i++) t += hw[i];
  return t;
}

/** retained share of the UNSEEN next-query attention mass */
function massOf(node: SpearNode, world: KvWorld, split: "train" | "test"): number {
  const pool = split === "train" ? world.train.map((s) => ({ feats: s, w: s.A })) : world.test.map((t) => ({ feats: t.feats, w: t.future }));
  let total = 0;
  for (const { feats, w } of pool) {
    let sc: Float64Array;
    try {
      sc = evaluateNode(node, feats, KV_SEQ);
    } catch {
      return -1;
    }
    for (let i = 0; i < KV_SEQ; i++) if (!Number.isFinite(sc[i])) return -1;
    total += topKWeightSum(sc, w, KV_KEEP);
  }
  // features are mean-normalised (× KV_SEQ); the evaluation weight stays a
  // probability mass, so we divide the accumulated sum back down.
  return (total / pool.length / KV_SEQ) * 100;
}

function buildKvTask(): TaskDef {
  const world = buildKvWorld();
  const gpConfig: GpConfig = {
    variables: ["A", "P", "S", "R"],
    constRange: [0.05, 4],
    ops: ["add", "sub", "mul", "pdiv", "max", "min"],
    maxDepth: 4,
    terminalVarProb: 0.7,
  };

  // selection happens on the observed (train) split only
  const trainMetric = (node: SpearNode): number => massOf(node, world, "train");
  // reported score is measured on the unseen next-query attention
  const testMetric = (node: SpearNode): number => massOf(node, world, "test");

  // Baselines share the exact same top-k routine on the SAME test split.
  const evalRule = (fn: (f: KvSample, i: number) => number): number => {
    let total = 0;
    for (const t of world.test) {
      const score = Float64Array.from({ length: KV_SEQ }, (_, i) => fn(t.feats, i));
      total += topKWeightSum(score, t.future, KV_KEEP);
    }
    return (total / world.test.length / KV_SEQ) * 100;
  };

  const ceiling = (() => {
    let total = 0;
    for (const t of world.test) total += topKWeightSum(t.future, t.future, KV_KEEP);
    return (total / world.test.length / KV_SEQ) * 100;
  })();

  const randomMetric = evalRule(() => rand());
  const windowMetric = evalRule((_, i) => (i >= KV_SEQ - KV_KEEP ? 1 : 0));
  const streamingMetric = evalRule((_, i) => (i < KV_SINK ? 3 : i >= KV_SEQ - KV_KEEP + KV_SINK ? 1 : 0));
  const h2oMetric = evalRule((f, i) => f.A[i]);
  const h2oWindowMetric = evalRule((f, i) => (f.A[i] + (i >= KV_SEQ - KV_KEEP ? 6 : 0)) * (i < KV_SINK ? 4 : 1));

  const baselines: TaskBaseline[] = [
    { name: "Aléatoire", metric: randomMetric, note: "Contrôle bas de l'échelle", kind: "statistical", formula: "rand" },
    { name: "Fenêtre glissante", metric: windowMetric, note: "Sliding window — défaut vLLM", kind: "heuristic", formula: "keep last 40" },
    { name: "StreamingLLM", metric: streamingMetric, note: "Sinks + fenêtre (Xiao et al. 2023)", kind: "heuristic", formula: "3·S + recency" },
    { name: "H2O (attention accumulée)", metric: h2oMetric, note: "Top-k sur Ā observé (Zhang et al. 2023)", kind: "heuristic", formula: "A" },
    { name: "H2O + fenêtre (type SnapKV)", metric: h2oWindowMetric, note: "Heuristique hybride la plus forte du lot", kind: "heuristic", formula: "4·S·A + 6·R" },
    { name: "Oracle (A futur, non observable)", metric: ceiling, note: "Plafond théorique — inaccessible au moment de la décision", kind: "oracle", formula: "top-k sur A_futur" },
  ];

  return {
    id: "kv_cache",
    family: "kv_cache",
    title: "Règle d'éviction du KV-cache",
    subtitle: `${KV_SEQ} tokens, budget ${KV_KEEP} (${(KV_SEQ / KV_KEEP).toFixed(0)}× compression) — sélection sur ${KV_TRAIN} requêtes passées, évaluée sur ${KV_TEST} requêtes futures`,
    groundTruth: "Score(A, P, S, R) — A = masse d'attention accumulée, normalisée par sa moyenne",
    metricLabel: "Masse d'attention future conservée (%)",
    metricDirection: "max",
    formatMetric: (m) => `${m.toFixed(2)} %`,
    variables: ["A", "P", "S", "R"],
    gpConfig,
    evaluate: (node) => ({ metric: trainMetric(node), finite: true }),
    holdout: (node) => ({ metric: testMetric(node), finite: true }),
    refine: (node) => {
      const res = refineConstants(node, (c) => -trainMetric(c), 24);
      return { node: res.node, evals: res.evals };
    },
    seedPool: [
      makeNode("var", { name: "A" }),
      makeNode("add", { children: [makeNode("var", { name: "A" }), makeNode("var", { name: "R" })] }),
      makeNode("add", { children: [makeNode("var", { name: "A" }), makeNode("mul", { children: [makeNode("const", { value: 2 }), makeNode("var", { name: "S" })] })] }),
      // StreamingLLM-style: heavy on sinks + recency
      makeNode("add", { children: [makeNode("mul", { children: [makeNode("const", { value: 4 }), makeNode("var", { name: "S" })] }), makeNode("mul", { children: [makeNode("const", { value: 2 }), makeNode("var", { name: "R" })] })] }),
      // SnapKV-style: attention with recency bonus
      makeNode("add", { children: [makeNode("mul", { children: [makeNode("const", { value: 4 }), makeNode("var", { name: "S" })] }), makeNode("add", { children: [makeNode("var", { name: "A" }), makeNode("mul", { children: [makeNode("const", { value: 3 }), makeNode("var", { name: "R" })] })] })] }),
      // H2O-style: attention with sink bonus
      makeNode("add", { children: [makeNode("var", { name: "A" }), makeNode("mul", { children: [makeNode("const", { value: 5 }), makeNode("var", { name: "S" })] })] }),
      // hybrid: A dominates, sinks and recency boost
      makeNode("add", { children: [
        makeNode("mul", { children: [makeNode("const", { value: 3 }), makeNode("var", { name: "S" })] }),
        makeNode("add", { children: [makeNode("mul", { children: [makeNode("const", { value: 1 }), makeNode("var", { name: "A" })] }), makeNode("mul", { children: [makeNode("const", { value: 4 }), makeNode("var", { name: "R" })] })] }),
      ] }),
      // multiplicative sink boost: sinks scale the whole score, not just add
      makeNode("mul", { children: [
        makeNode("add", { children: [makeNode("var", { name: "A" }), makeNode("var", { name: "R" })] }),
        makeNode("add", { children: [makeNode("const", { value: 1 }), makeNode("mul", { children: [makeNode("const", { value: 3 }), makeNode("var", { name: "S" })] })] }),
      ] }),
      makeNode("max", { children: [
        makeNode("add", { children: [makeNode("var", { name: "A" }), makeNode("var", { name: "R" })] }),
        makeNode("mul", { children: [makeNode("var", { name: "S" }), makeNode("const", { value: 8 })] }),
      ] }),
      makeNode("mul", { children: [
        makeNode("var", { name: "A" }),
        makeNode("add", { children: [makeNode("const", { value: 1 }), makeNode("mul", { children: [makeNode("const", { value: 3 }), makeNode("var", { name: "S" })] })] }),
      ] }),
    ],
    baselines,
    // Calibrated against the measured oracle ceiling: milestones are expressed
    // as "gap closed" so they stay reachable whatever the world seed produces.
    milestones: [
      { level: 1, label: `≥ ${(ceiling - 22).toFixed(0)} % de masse future`, test: (m) => m >= ceiling - 22 },
      { level: 2, label: `≥ ${(ceiling - 12).toFixed(0)} %`, test: (m) => m >= ceiling - 12 },
      { level: 3, label: `Toutes les heuristiques dépassées (≥ ${(ceiling - 7).toFixed(0)} %)`, test: (m) => m >= ceiling - 7 },
      { level: 4, label: `Gap oracle fermé à 75 % (≥ ${(ceiling - 3.5).toFixed(0)} %)`, test: (m) => m >= ceiling - 3.5 },
      { level: 5, label: `Gap oracle fermé à 90 % (≥ ${(ceiling - 1.5).toFixed(0)} %)`, test: (m) => m >= ceiling - 1.5 },
    ],
    verify: (node) => {
      const dump = JSON.stringify(node);
      const usesSink = dump.includes('"name":"S"');
      const usesRecency = dump.includes('"name":"R"');
      const usesAttention = dump.includes('"name":"A"');
      if (usesAttention && usesRecency && usesSink) {
        return "Règle tri-dimensionnelle A + S + R : heavy hitters + attention sinks + récence, la triade que la littérature a mise des années à identifier.";
      }
      if (usesAttention && usesRecency) return "Combine attention accumulée et récence (proche SnapKV).";
      return null;
    },
    codeVarDecl: "const float A, const float P, const float S, const float R",
  };
}

// ---------------------------------------------------------------------------
// REGRESSION TASKS — recover closed-form physical laws from noisy data
// ---------------------------------------------------------------------------

function buildRegressionTask(cfg: {
  id: string;
  title: string;
  subtitle: string;
  groundTruth: string;
  rows: number;
  varNames: string[];
  build: () => { vars: Record<string, Float64Array>; y: Float64Array };
  /** the exact generating law — used ONLY to measure the irreducible noise
   *  floor, never exposed to the search */
  trueLaw: (vars: Record<string, Float64Array>, i: number) => number;
  verify: (node: SpearNode) => string | null;
}): TaskDef {
  const { vars, y } = cfg.build();
  const n = y.length;
  const varNames = cfg.varNames;
  const gpConfig: GpConfig = {
    variables: varNames,
    constRange: [-6, 6],
    ops: GP_OPS,
    maxDepth: 5,
    terminalVarProb: 0.55,
  };
  const scoreOf = (node: SpearNode): number => {
    try {
      const p = evaluateNode(node, vars, n);
      for (let i = 0; i < n; i++) if (!Number.isFinite(p[i])) return Infinity;
      return mse(p, y);
    } catch {
      return Infinity;
    }
  };
  const lin = ols1(vars[varNames[0]], y);
  let meanY = 0;
  for (let i = 0; i < n; i++) meanY += y[i];
  meanY /= n;
  let variance = 0;
  for (let i = 0; i < n; i++) variance += (y[i] - meanY) ** 2;
  variance /= n;
  // Irreducible noise floor: the MSE the EXACT generating law itself scores
  // against the noisy observations. No formula can do meaningfully better;
  // anything below ~1.0x is fitting the noise, not the physics. Absolute MSE
  // milestones would be unreachable by construction, so we calibrate on this.
  let noiseFloor = 0;
  for (let i = 0; i < n; i++) noiseFloor += (cfg.trueLaw(vars, i) - y[i]) ** 2;
  noiseFloor /= n;

  return {
    id: cfg.id,
    family: "regression",
    title: cfg.title,
    subtitle: cfg.subtitle,
    groundTruth: cfg.groundTruth,
    metricLabel: "MSE",
    metricDirection: "min",
    formatMetric: (m) => (m < 1e-12 ? "0" : m.toExponential(2)),
    variables: varNames,
    gpConfig,
    evaluate: (node) => {
      try {
        const p = evaluateNode(node, vars, n);
        for (let i = 0; i < n; i++) if (!Number.isFinite(p[i])) return { metric: Infinity, finite: false };
        return { metric: mse(p, y), secondary: linfError(p, y), finite: true };
      } catch {
        return { metric: Infinity, finite: false };
      }
    },
    evaluateScored: (node) => {
      try {
        const p = evaluateNode(node, vars, n);
        for (let i = 0; i < n; i++) if (!Number.isFinite(p[i])) return { metric: Infinity, finite: false, node };
        const { a, b } = fitLinearScaling(p, y);
        const wrapped = wrapAffine(node, a, b);
        const wp = evaluateNode(wrapped, vars, n);
        for (let i = 0; i < n; i++) if (!Number.isFinite(wp[i])) return { metric: Infinity, finite: false, node: wrapped };
        return { metric: mse(wp, y), secondary: linfError(wp, y), finite: true, node: wrapped };
      } catch {
        return { metric: Infinity, finite: false, node };
      }
    },
    refine: (node) => {
      try {
        const p = evaluateNode(node, vars, n);
        const { a, b } = fitLinearScaling(p, y);
        const res = refineConstants(wrapAffine(node, a, b), scoreOf, 40);
        return { node: res.node, evals: res.evals + 1 };
      } catch {
        return { node, evals: 0 };
      }
    },
    seedPool: [
      makeNode("sq", { children: [makeNode("var", { name: varNames[0] })] }),
      makeNode("mul", { children: [makeNode("var", { name: varNames[0] }), makeNode("sqrt", { children: [makeNode("var", { name: varNames[0] })] })] }),
      makeNode("sqrt", { children: [makeNode("cube", { children: [makeNode("var", { name: varNames[0] })] })] }),
      makeNode("cube", { children: [makeNode("var", { name: varNames[0] })] }),
    ],
    baselines: [
      { name: "Loi exacte (plancher de bruit)", metric: noiseFloor, note: "MSE de la vraie loi sur les données bruitées — optimum atteignable", kind: "oracle", formula: cfg.groundTruth },
      { name: "Régression linéaire (MCQ)", metric: lin.mse, note: `y = ${lin.a.toFixed(4)}·${varNames[0]} + ${lin.b.toFixed(4)}`, kind: "statistical", formula: "OLS" },
      { name: "Moyenne constante", metric: (() => { let m = 0; for (let i = 0; i < n; i++) m += y[i]; m /= n; let s = 0; for (let i = 0; i < n; i++) s += (y[i] - m) ** 2; return s / n; })(), note: "Variance totale du jeu de données", kind: "statistical", formula: "ȳ" },
    ],
    // Calibrated on the measured noise floor, not on arbitrary absolute
    // thresholds: reaching ~1x the floor means the recovered law is
    // statistically indistinguishable from the true generating law.
    milestones: [
      { level: 1, label: `MSE < variance/10 (${(variance / 10).toExponential(1)})`, test: (m) => m < variance / 10 },
      { level: 2, label: `Bat l'OLS ×10 (${(lin.mse / 10).toExponential(1)})`, test: (m) => m < lin.mse / 10 },
      { level: 3, label: `≤ 3× le plancher de bruit (${(noiseFloor * 3).toExponential(1)})`, test: (m) => m <= noiseFloor * 3 },
      { level: 4, label: `≤ 1.5× le plancher (${(noiseFloor * 1.5).toExponential(1)})`, test: (m) => m <= noiseFloor * 1.5 },
      { level: 5, label: `≤ 1.1× le plancher — loi indiscernable de la vraie (${(noiseFloor * 1.1).toExponential(1)})`, test: (m) => m <= noiseFloor * 1.1 },
    ],
    chart: (node) => {
      const p = evaluateNode(node, vars, n);
      const out: { x: number; target: number; predicted: number }[] = [];
      const step = Math.max(1, Math.floor(n / 60));
      for (let i = 0; i < n; i += step) out.push({ x: i, target: y[i], predicted: p[i] });
      return out;
    },
    verify: cfg.verify,
    codeVarDecl: `const float ${varNames.join(", const float ")}`,
  };
}

function freeFallData(): { vars: Record<string, Float64Array>; y: Float64Array } {
  const rows = 48;
  const t = linspace(0, 3, rows);
  const y = new Float64Array(rows);
  for (let i = 0; i < rows; i++) y[i] = 0.5 * 9.81 * t[i] * t[i] + gaussianRandom() * 0.02;
  return { vars: { t }, y };
}

function keplerData(): { vars: Record<string, Float64Array>; y: Float64Array } {
  const rows = 40;
  const a = linspace(0.3, 30, rows);
  const y = new Float64Array(rows);
  for (let i = 0; i < rows; i++) y[i] = Math.pow(a[i], 1.5) * (1 + gaussianRandom() * 0.004);
  return { vars: { a }, y };
}

// ---------------------------------------------------------------------------
// Registry
// ---------------------------------------------------------------------------

export function buildTasks(): TaskDef[] {
  return [
    buildActivationTask({
      id: "silu",
      title: "SiLU / Swish (LLaMA · Mistral · Qwen — SwiGLU)",
      fn: silu,
      lo: -6,
      hi: 6,
      groundTruth: "SiLU(x) = x·σ(x) = x / (1 + e⁻ˣ)",
    }),
    buildActivationTask({ id: "gelu", title: "GELU (GPT · BERT — GEGLU)", fn: (x) => 0.5 * x * (1 + erf(x / Math.SQRT2)), lo: -6, hi: 6, groundTruth: "GELU(x) = 0.5x(1 + erf(x/√2))" }),
    buildActivationTask({ id: "sigmoid", title: "Sigmoid (routage MoE · portes d'attention)", fn: (x) => 1 / (1 + Math.exp(-x)), lo: -8, hi: 8, groundTruth: "σ(x) = 1 / (1 + e⁻ˣ)" }),
    buildKvTask(),
    buildRegressionTask({
      id: "free_fall",
      title: "Loi de chute libre",
      subtitle: "48 mesures bruitées (σ ≈ 2 cm) de distance vs. temps",
      groundTruth: "d = ½·g·t² avec g = 9.81 m·s⁻²",
      rows: 48,
      varNames: ["t"],
      build: freeFallData,
      trueLaw: (v, i) => 0.5 * 9.81 * v.t[i] * v.t[i],
      verify: (node) => {
        const c = evaluateScalar(node, { t: 1 });
        if (!Number.isFinite(c)) return null;
        const err = Math.abs(c - 4.905);
        return err < 0.05 ? `g retrouvé = ${(c * 2).toFixed(3)} m·s⁻² (erreur ${(err * 2 / 9.81 * 100).toFixed(2)} %)` : null;
      },
    }),
    buildRegressionTask({
      id: "kepler",
      title: "3ᵉ loi de Kepler",
      subtitle: "40 orbites (0.3 → 30 UA), bruit 0.4 %",
      groundTruth: "T = a^1.5 (UA, années) — exposant 3/2 non entier",
      rows: 40,
      varNames: ["a"],
      build: keplerData,
      trueLaw: (v, i) => Math.pow(v.a[i], 1.5),
      verify: (node) => {
        const at4 = evaluateScalar(node, { a: 4 });
        if (!Number.isFinite(at4)) return null;
        const err = Math.abs(at4 - 8) / 8;
        return err < 0.01 ? `T(4 UA) = ${at4.toFixed(3)} an (théorie 8.000) — exposant 3/2 retrouvé` : null;
      },
    }),
  ];
}

export function taskOpProfile(node: SpearNode): { total: number; transcendental: number } {
  return countOps(node);
}
